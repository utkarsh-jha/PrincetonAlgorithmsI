import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {

    private final int experimentNo;
    private final double fractions[];

    // perform independent trials on an n-by-n grid
    public PercolationStats(int n, int trials) {
        if (n <= 0 || trials <= 0) {
            throw new IllegalArgumentException();
        }

        experimentNo = trials;
        fractions = new double[experimentNo];
        Percolation p = new Percolation(n);
        for (int i = 0; i < trials; i++) {
            while (!p.percolates()) {
                p.open(StdRandom.uniform(n), StdRandom.uniform(n));
            }
            double fraction = (double) p.numberOfOpenSites() / (n * n);
            fractions[i] = fraction;
//            fraction[i] = (double) p.numberOfOpenSites()/(n*n);
        }

    }

    // sample mean of percolation threshold
    public double mean() {
        return StdStats.mean(fractions);
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        return StdStats.stddev(fractions);
    }

    // low endpoint of 95% confidence interval
    public double confidenceLo() {
        return mean() - ((1.96 * stddev()) / Math.sqrt(experimentNo));
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        return mean() + ((1.96 * stddev()) / Math.sqrt(experimentNo));
    }

    private void printResults() {
        edu.princeton.cs.algs4.StdOut.printf("%-23s = %f\n", "mean", mean());
        edu.princeton.cs.algs4.StdOut.printf("%-23s = %f\n", "var", StdStats.var(fractions));
        edu.princeton.cs.algs4.StdOut.printf("%-23s = %f\n", "stddev", stddev());
        edu.princeton.cs.algs4.StdOut
                .printf("%-23s = [%f, %f]\n", "95% confidence interval", confidenceLo(), confidenceHi());
    }

    // test client (see below)
    public static void main(String[] args) {
        int N = Integer.parseInt(args[0]);
        int T = Integer.parseInt(args[1]);
        PercolationStats ps = new PercolationStats(N, T);
//        PercolationStats ps = new PercolationStats(200, 100);
        ps.printResults();

    }


}