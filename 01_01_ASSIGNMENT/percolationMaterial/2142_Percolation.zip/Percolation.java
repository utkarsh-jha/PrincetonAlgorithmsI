public class Percolation {

    private final int total;
    private final int matrixSize;
    private final int[] a;
    private int openSites = 0;

    public Percolation(int n) {
        if (n <= 0) throw new IllegalArgumentException();
        this.matrixSize = n;
        this.total = n * n;
        a = new int[total];
        for (int i = 0; i < total; i++) {
            a[i] = -1;
        }
    }

    private int mapRowColToIndex(int row, int col) {
        return (row - 1) * matrixSize + (col - 1);
    }



    private String positionType(int index) {
        String s = "";
        if (index < matrixSize) {
            s += "T";
        }

        if (index >= total - matrixSize) {
            s += "B";
        }

        if (index % matrixSize == 0) {
            s += "L";
        }

        if ((index + 1) % matrixSize == 0) {
            s += "R";
        }

        return s.equals("") ? "M" : s;
    }

    public void open(int row, int col) {
        if (row > matrixSize || col > matrixSize || row <= 0 || col <= 0) {
            throw new IllegalArgumentException();
        }

        if (!isOpen(row, col)) {
            int index = mapRowColToIndex(row, col);
            String s = positionType(index);
            a[index] = index;

            int above = index - matrixSize;
            int below = index + matrixSize;
            int left = index - 1;
            int right = index + 1;

            if (!s.contains("T") && isOpen(above)) {
                union(above, index);
            }

            if (!s.contains("B") && isOpen(below)) {
                union(below, index);
            }

            if (!s.contains("R") && isOpen(right)) {
                union(right, index);
            }

            if (!s.contains("L") && isOpen(left)) {
                union(left, index);
            }
            openSites = openSites + 1;
        }

    }

    public boolean isOpen(int row, int col) {
        if (row > matrixSize || col > matrixSize || row <= 0 || col <= 0) {
            throw new IllegalArgumentException();
        }
        int index = mapRowColToIndex(row, col);
        return isOpen(index);
    }

    private boolean isOpen(int index) {
        return a[index] != -1;
    }

    public boolean isFull(int row, int col) {
        if (row > matrixSize || col > matrixSize || row <= 0 || col <= 0) {
            throw new IllegalArgumentException();
        }
        int index = mapRowColToIndex(row, col);
        if (isOpen(index)) {
            for (int i = 0; i < matrixSize; i++) {
                if (isOpen(i) && isConnected(index, i)) {
                    return true;
                }
            }
        }
        return false;
    }

    public int numberOfOpenSites() {
        return openSites;
    }

    public boolean percolates() {
        for (int j = 0; j < matrixSize; j++) {
            if (isOpen(j)) {
                for (int k = total - matrixSize; k < total; k++) {
                    if (isOpen(k) && isConnected(k, j)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private int root(int index) {
        while (index != a[index]) {
            index = a[index];
        }
        return index;
    }

    private boolean isConnected(int index1, int index2) {
        return root(index1) == root(index2);
    }

    private void union(int index1, int index2) {
        int i = root(index1);
        int j = root(index2);
        a[i] = j;
    }

    public static void main(String[] args) {
        Percolation p = new Percolation(10);
        p.open(5, -1);
    }


}
