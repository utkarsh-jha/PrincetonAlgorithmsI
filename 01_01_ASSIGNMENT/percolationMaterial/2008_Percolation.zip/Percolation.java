// public class Percolation {
//
//     private final int n;
//     private final int matrixSize;
//     private int[] a;
//
//     private void validate(int row, int col) {
//
//         if (mapRowColToIndex(row, col) < 0 || mapRowColToIndex(row, col) >= n) {
//
//             throw new IllegalArgumentException();
//         }
//     }
//
//     private int mapRowColToIndex(int row, int col) {
//         return (row-1) * matrixSize + (col-1);
//     }
//
//     public Percolation(int n) {
//         if (n <= 0) {
//             throw new IllegalArgumentException();
//         }
//         this.matrixSize = n;
//         n = n * n;
//         this.n = n;
//         a = new int[n];
//         for (int i = 1; i <= n; i++) {
//             a[i - 1] = 0;
//         }
//         //System.out.println(this.matrixSize);
//     }
//
//     private String positionType(int index) {
//         String p = "";
//         if (index < matrixSize) {
//             p += 'T';
//         }
//         if (index >= (n - matrixSize)) {
//             p += 'B';
//         }
//         if ((index) % matrixSize == 0) {
//             p += 'L';
//         }
//         if ((index +1 ) % matrixSize == 0) {
//             p += 'R';
//         }
//         if (p.equals("")) {
//             p += "M";
//         }
//         return p;
//     }
//
//     public void open(int row, int col) {
//         validate(row, col);
//         int ind = mapRowColToIndex(row, col);
//
//         a[ind] = ind+1;
//
//         String s = positionType(mapRowColToIndex(row, col));
//
//         if (!s.contains("T")) {
//             if (isOpen(ind - matrixSize)) {
//                 union(ind - matrixSize, ind);
//             }
//         }
//         System.out.println(isFull(row,col));
//         /*
//         if (!s.contains("L")) {
//             if (isOpen(ind - 1)) {
//                 union(ind - 1, ind);
//             }
//         }
//         if (!s.contains("B")) {
//             if (isOpen(ind + matrixSize)) {
//                 union(ind + matrixSize, ind);
//             }
//         }
//         if (!s.contains("R")) {
//             if (isOpen(ind + 1)) {
//                 union(ind + 1, ind);
//             }
//         }
//         */
//
//         //printMatrix();
//     }
//
//     public boolean isOpen(int row, int col) {
//         validate(row, col);
//         return isOpen(mapRowColToIndex(row, col));
//     }
//
//     private boolean isOpen(int index) {
//         return a[index] != 0;
//     }
//
//     public boolean isFull(int row, int col) {
//         validate(row, col);
//         int index = mapRowColToIndex(row, col);
//         if (isOpen(index)) {
//             for (int i = 0; i < matrixSize; i++) {
//                 if (a[index] == a[i]) {
//                     return true;
//                 }
//             }
//         }
//         return false;
//     }
//
//     public int numberOfOpenSites() {
//         int count = 0;
//         for (int i = 0; i < n; i++) {
//             if (a[i] != -1) {
//                 count += 1;
//             }
//         }
//         return count;
//     }
//
//     public boolean percolates() {
//         for (int i = 0; i < matrixSize; i++) {
//             for (int j = n - matrixSize; j < n; j++) {
//                 if (isOpen(i) && isOpen(j) && isConnected(i, j)) return true;
//             }
//         }
//         return false;
//     }
//
//     private int root(int index) {
//         System.out.println(a[index] + "a[index]" + index);
//         a[index] += 1;
//         int count = 0;
//         while (a[index] != index) {
//             System.out.println(index + " is index " + a[index] + " is a[index]");
//             index = a[index];
//         }
//         System.out.println("return ");
//         return index;
//     }
//
//     private boolean isConnected(int index1, int index2) {
//         return root(index1) == root(index2);
//     }
//
//     private void union(int index1, int index2) {
//         int i = root(index1);
//         int j = root(index2);
//         a[i] = j;
//     }
//
//     public int[] getA() {
//         return a;
//     }
//
//     //for testing only
//     public static void main(String[] args) {
//         Percolation p = new Percolation(5);
//         int l[] = p.getA();
//         for (int i = 1; i < 5 ; i++) {
//             for (int j = 1; j < 5; j++) {
//                 System.out.println( p.isOpen(i,j));
//                 System.out.println( p.isFull(i,j));
//             }
//
//         }
//     }
// }
public class Percolation {

    private final int total;
    private final int matrixSize;
    private final int[] a;
    private int openSites = 0;

    public Percolation(int n) {
        if (n <= 0) throw new IllegalArgumentException();
        this.matrixSize = n;
        this.total = n * n;
        a = new int[total];
        for (int i = 0; i < total; i++) {
            a[i] = -1; //closed
        }
    }

    private int mapRowColToIndex(int row, int col) {
        return (row - 1) * matrixSize + (col - 1);
    }

    private void validate(int row, int col) {
        int index = mapRowColToIndex(row, col);
        if (index < 0 || index > total) {
            throw new IllegalArgumentException();
        }
    }

    private String positionType(int index) {
        String s = "";
        if (index < matrixSize) {
            s += "T";
        }

        if (index >= total - matrixSize) {
            s += "B";
        }

        if (index % matrixSize == 0) {
            s += "L";
        }

        if ((index + 1) % matrixSize == 0) {
            s += "R";
        }

        return s.equals("") ? "M" : s;
    }

    public void open(int row, int col) {
        openSites += 1;
        validate(row, col);
        int index = mapRowColToIndex(row, col);
        String s = positionType(index);
        a[index] = index;

        int above = index - matrixSize;
        int below = index + matrixSize;
        int left = index - 1;
        int right = index + 1;

        if (!s.contains("T") && isOpen(above)) {
            union(above, index);
        }

        if (!s.contains("B") && isOpen(below)) {
            union(below, index);
        }

        if (!s.contains("R") && isOpen(right)) {
            union(right, index);
        }

        if (!s.contains("L") && isOpen(left)) {
            union(left, index);
        }
    }

    public boolean isOpen(int row, int col) {
        validate(row, col);
        int index = mapRowColToIndex(row, col);
        return isOpen(index);
    }

    private boolean isOpen(int index) {
        return a[index] != -1;
    }

    public boolean isFull(int row, int col) {
        int index = mapRowColToIndex(row, col);
        if (isOpen(index)) {
            for (int i = 0; i < matrixSize; i++) {
                if (isOpen(i) && isConnected(index, i)) {
                    return true;
                }
            }
        }
        return false;
    }

    public int numberOfOpenSites() {
        return openSites;
    }
    public boolean percolates() {
            for (int j = 0; j < matrixSize; j++) {
                if (isOpen(j)) {
                    for (int k = total-matrixSize ; k < total  ; k++) {
                        if(isOpen(k) && isConnected(k, j)){
                            return true;
                        }
                    }
                }
            }
        return false;
    }

    private int root(int index) {
        while (index != a[index]) {
            index = a[index];
        }
        return index;
    }

    private boolean isConnected(int index1, int index2) {
        return root(index1) == root(index2);
    }

    private void union(int index1, int index2) {
        int i = root(index1);
        int j = root(index2);
        a[i] = j;
    }


    public static void main(String[] args) {
        Percolation p = new Percolation(3);



    }
}
